let num1 = 1;
let num2 = 2;

let soma = num1 + num2;
let sub = num1 - num2;
let mult = num1 * num2;
let div = num1 / num2;

console.log(soma);
console.log(sub);
console.log(mult);
console.log(div);